import React from 'react'
import MapComponent from '../components/Map/MapComponent'
import FilterSelect from '../components/FilterSelect/FilterSelect'
import Navbar from '../components/Navbar/Navbar'
import './mapPage.css'

const MapPage: React.FC = () => {
  return (
    <div className='mapPage'>
      <div className='navbar'>
      <Navbar />
      </div>
      <div className='filterSelect'>
      <FilterSelect />
      </div>
      <div className='map'>
      <MapComponent />
      </div>
    </div>
  )
}

export default MapPage;