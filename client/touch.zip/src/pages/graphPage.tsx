import React from 'react'

const graphPage = () => {
  return (
    <div>graphPage</div>
  )
}

export default graphPage