import React, { useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMapEvent } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { useSelector } from "react-redux";

// Israel Middle Point (Latitude, Longitude)
const IsraelMiddlePoint: [number, number] = [31.0461, 34.8516];



const MapComponent: React.FC = () => {
  const [position, setPosition] = useState<[number, number] | null>(null);
  const attackData = useSelector((state: RootState) => state.attackData);

  // רכיב שמאזין ללחיצה על המפה
  const ClickHandler = () => {
    useMapEvent("click", (event) => {
      const { lat, lng } = event.latlng;
      setPosition([lat, lng]);
    });
    return null; // לא מחזיר שום דבר למעט ההאזנה לאירועים
  };

  return (
    <div className="map-container">
      <MapContainer
        center={[0,0]}
        zoom={2}
        style={{ height: "900px", width: "100%" }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        {/* רכיב ה-ClickHandler עכשיו מותקן בתוך MapContainer */}
        <ClickHandler />

        {position && (
          <Marker position={position} icon={new L.Icon({ iconUrl: "https://cdn-icons-png.flaticon.com/512/2525/2525379.png", iconSize: [25, 25] })}>
            <Popup>
              Latitude: {position[0]} <br />
              Longitude: {position[1]}
            </Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  );
};

export default MapComponent;