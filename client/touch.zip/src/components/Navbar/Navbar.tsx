import React from 'react'
import '../../App.css'

const Navbar = () => {
  return (
    <div className='navbar'>Navbar</div>
  )
}

export default Navbar