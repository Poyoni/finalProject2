import React, { useState } from 'react';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { fetchHighestCasualtyRegions, fetchDeadliestAttacks, fetchTopGroups } from '../../app/featuers/data/dataSlice';
import { AppDispatch } from '../../app/store';

const FilterSelect = () => {
  const [selectedRegion, setSelectedRegion] = useState('');
  const [selectedOption, setSelectedOption] = useState('');
  const [additionalOption, setAdditionalOption] = useState('');
  const dispatch = useDispatch<AppDispatch>()
  const [formData, setFormData] = useState({
    year: '',
    range: '',
    area: '',
    organization: '',
  });

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedOption(e.target.value);
  };

  const handleFormChange = (event: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = event.target;
    setSelectedRegion(value);
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  
  

  const handleSubmit = async () => {

    try {

      if (selectedOption === 'getDeadliestAttacks') {
        dispatch(fetchDeadliestAttacks())
      } else if (selectedOption === 'getHighestCasualtyRegions') {
        dispatch(fetchHighestCasualtyRegions(selectedRegion));
        console.log(selectedRegion)
      } else if (selectedOption === 'getIncidentTrends') {
        dispatch(fetchTopGroups(selectedRegion))
        console.log(selectedRegion)
      } else if (selectedOption === 'getTopGroups') {
        window.location.href = '/map';
      } else if (selectedOption === 'getGroupsByYear') {
        window.location.href = '/data';
      } else if (selectedOption === 'getDeadliestRegions') {
        window.location.href = '/regions';
      }
    } catch (error){
      console.log (error)
    };

  };

  return (
    <div>
      <h3>בחר סוג בקשה</h3>
      <select value={selectedOption} onChange={handleSelectChange}>
        <option value="">בחר אפשרות</option>
        <option value="getDeadliestAttacks">דירוג של סוגי המתקפות</option>
        <option value="getHighestCasualtyRegions">איזורים עם ממוצע הגבוה ביותר בכל פיגוע</option>
        <option value="getIncidentTrends">מגמות שנתיות</option>
        <option value="getTopGroups">אירגונים בוטלים לפי איזור</option>
        <option value="getGroupsByYear">אירוגנים שפעלו לפי שנה</option>
        <option value="getDeadliestRegions">איזורים שנפגעו לפי ארגון</option>
      </select>



      {selectedOption === 'getHighestCasualtyRegions' && (
        <div>
          <select
            value={selectedRegion}
            name="region"
            onChange={handleFormChange}
          >
            <option>בחר סוג סינון</option>
            <option value="region_txt">סנן לפי איזור</option>
            <option value="country_txt">סנן לפי מדינה</option>
            <option value="city">סנן לפי עיר</option>
          </select>
        </div>
      )}

      {selectedOption === 'getIncidentTrends' && (
        <div>
          <select
            value={formData.range}
            name="range"
            onChange={handleFormChange}
          >
            <option value="specificYear">בחירת שנה ספציפית</option>
            <option value="years">בחירת טווח שנים</option>
            <option value="last5years">5 שנים אחרונות</option>
            <option value="last10years">10 שנים אחרונות</option>
          </select>

          {formData.range === 'specificYear' && (
            <div>
              <label>בחר שנה:</label>
              <input
                type="text"
                name="year"
                value={formData.year}
                onChange={handleFormChange}
              />
            </div>
          )}
        </div>
      )}

      {selectedOption === 'getTopGroups' && (
        <div>
          <label>בחר איזור:</label>
          <input
            type="text"
            name="area"
            value={formData.area}
            onChange={handleFormChange}
          />
          {/* <div>
            <label>סינון:</label>
            <select
              name="filter"
              value={additionalOption}
              onChange={(e) => setAdditionalOption(e.target.value)}
            >
              <option value="top5">טופ 5</option>
              <option value="all">כולם</option>
            </select>
          </div> */}
        </div>
      )}

      {selectedOption === 'getGroupsByYear' && (
        <div>
          <label>בחר ארגון:</label>
          <select
            name="organization"
            value={formData.organization}
            onChange={handleFormChange}
          >
            <option value="organization">בחר ארגון</option>

          </select>
          <label>בחר שנה:</label>
          <select
            name="year"
            value={formData.year}
            onChange={handleFormChange}
          >
            <option value="year">בחר שנה</option>

          </select>
        </div>
      )}

      {selectedOption === 'getDeadliestRegions' && (
        <div>
          <label>הכנס שם ארגון:</label>
          <input
            type="text"
            name="organizationName"
            value={formData.organization}
            onChange={handleFormChange}
          />
        </div>
      )}

      <button onClick={handleSubmit}>שלח</button>
    </div>
  );
};

export default FilterSelect;
