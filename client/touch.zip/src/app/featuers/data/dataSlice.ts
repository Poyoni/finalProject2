import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import {ITerrorAttack} from '../../../types/attackType'
import axios from 'axios';

interface RegionState {
  data: ITerrorAttack[] | any ;
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}



const initialState: RegionState = {
  data: null,
  status: 'idle',
  error: null,
};



export const fetchHighestCasualtyRegions = createAsyncThunk(
  'regions/fetchHighestCasualtyRegions',
  async (region: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/analysis/highest-casualty-regions/?region=${region}`);
      console.log(response.data)
      return response.data;

    } catch (error: any) {
      return rejectWithValue(error.response?.data || 'משהו השתבש');
    }
  }
);

export const fetchDeadliestAttacks = createAsyncThunk(
  'regions/fetchDeadliestAttacks',
  async () => {
    try{
      const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/analysis/deadliest-attack-types/`);
      console.log(response.data)
      return response.data;
    }catch(error){
      return error
    }
  }
)

export const fetchTopGroups = createAsyncThunk(
  'regions/fetchTopGroups',
  async (region: string) => {
    try{
      const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/relationships/top-groups/${region}`);
      console.log(response.data)
      return response.data;
    }catch(error){
      return error
    }
  }
)

const dataSlice = createSlice({
  name: 'regions',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchHighestCasualtyRegions.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(fetchHighestCasualtyRegions.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.data = action.payload;
      })
      .addCase(fetchHighestCasualtyRegions.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload as string;
      });
  },
});

export default dataSlice.reducer;
